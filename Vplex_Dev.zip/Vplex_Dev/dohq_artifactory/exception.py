class ArtifactoryException(Exception):
    pass
