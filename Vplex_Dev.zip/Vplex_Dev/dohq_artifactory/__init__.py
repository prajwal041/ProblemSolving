from dohq_artifactory.admin import *  # noqa
